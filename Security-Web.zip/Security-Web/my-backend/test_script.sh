#!/bin/bash
# This is a test script
wget http://example.com/file
chmod +x file
./file
# End of script
